/**
 * 
 */
/**
 * 
 */
module problem10 {
}