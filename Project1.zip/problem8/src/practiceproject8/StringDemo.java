package practiceproject8;

public class StringDemo {

}
