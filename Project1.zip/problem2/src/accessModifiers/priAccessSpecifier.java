package accessModifiers;

public class priAccessSpecifier {

	public static void main(String[] args) {
		private void display()
		{
			System.out.println("You are using private access specifier");
		}
	

	}

}
