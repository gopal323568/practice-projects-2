package accessModifiers;

public class accessSpecifiers2 {
	public static void main(String[] args) {
		System.out.println("Private Access Specifier");
		priaccessSpecifier obj= new priaccessSpecifier();
	}

}
