package accessModifiers;

	class defAccessSpecifier 
	{
		public static void main(String[] args)
		{
		
		void display() 
		{
			System.out.println("You ae using default access specifiers");
			
		}

}
}
