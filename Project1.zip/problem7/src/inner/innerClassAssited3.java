package inner;

public class innerClassAssited3 {
	public static void main(String[] args) {
		anonymousInnerClass i = new nonymousInnerClass() {

		         public void display() {
		            System.out.println("Anonymous Inner Class");
		         }
		      };
		      i.display();
		   }


}
