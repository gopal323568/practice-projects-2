package inner;

abstract class anonymousInnerClass {
	public abstract void display()

}

