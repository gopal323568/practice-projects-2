package collection;

public class collectionAssited {

}
