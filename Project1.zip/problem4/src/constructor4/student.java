package constructor4;

public class student {
	int id;
	String name;

	Studen(int i,String n)
	{
	id=i;
	name=n;
	}

	void display() {
	System.out.println(id+" "+name);
	}


}
