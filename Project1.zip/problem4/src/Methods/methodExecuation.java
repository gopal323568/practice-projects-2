package Methods;

public class methodExecuation {
	public int multipynumbers(int a,int b) {
		int z=a*b;
		return z;
	}

	public static void main(String[] args) {

		methodExecuation b=new methodExecuation();
		int ans= b.multipynumbers(20,6);
		System.out.println("Multipilcation is :"+ans);
	}


}
