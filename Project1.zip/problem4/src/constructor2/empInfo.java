package constructor2;

public class empInfo {
	int id;
	String name;

void display() {
	System.out.println(id+" "+name);
	}


}
