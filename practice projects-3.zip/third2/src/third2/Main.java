package third2;
import java.util.Arrays;

public class Main {
    public static void main(String[] args) {
        int[] array = {1, 2, 3, 4, 5};
        int rotations = 5;

        for (int i = 0; i < rotations; i++) {
            rotateRight(array);
        }

        System.out.println(Arrays.toString(array));
    }

    public static void rotateRight(int[] array) {
        // 2. Copy last element of array
        int lastElement = array[array.length - 1];

        // 3. Shift all elements of array to the right
        for (int i = array.length - 1; i > 0; i--) {
            array[i] = array[i - 1];
        }

        // 4. Replace first element of array with last element copied in step 2
        array[0] = lastElement;
    }
}
