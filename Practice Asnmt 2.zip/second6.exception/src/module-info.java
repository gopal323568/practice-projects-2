/**
 * 
 */
/**
 * 
 */
module second6.exception {
}