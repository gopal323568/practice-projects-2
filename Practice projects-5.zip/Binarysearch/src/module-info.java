/**
 * 
 */
/**
 * 
 */
module Binarysearch {
}